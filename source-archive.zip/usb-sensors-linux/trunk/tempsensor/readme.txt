
TempSensor
----------

Read me file:

http://code.google.com/p/usb-sensors-linux/wiki/ReadMe_TempSensor

Version history:

http://code.google.com/p/usb-sensors-linux/wiki/VersionHistory_TempSensor

Installation guide for linux:

http://code.google.com/p/usb-sensors-linux/wiki/Install_TempSensor_Linux

Author:

Sebastian Sjoholm, sebastian.sjoholm@gmail.com
